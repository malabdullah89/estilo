for run the proyect i highly recommend using yarn install to get all the dependencies
then
run yarn start it will open in the browser in http://localhost:3000/index
